function getXAxis(unit) {
  let today = new Date();
  let xAxis = [];
  if (unit == "hour") {
    let currentHour = today.getHours();
    if (currentHour < 10) {
      currentHour = "0" + currentHour;
    }
    xAxis = [currentHour.toString()];
    for (let i = 1; i < 7; i++) {
      let newDate = new Date(today.setHours(today.getHours() - 1));
      let hour = newDate.getHours();
      if (hour < 10) {
        hour = "0" + hour;
      }
      xAxis.push(hour.toString());
    }
  } else if (unit == "day") {
    let currentDay = today.getDate();
    if (currentDay < 10) {
      currentDay = "0" + currentDay.toString();
    }
    xAxis = [currentDay + "-" + String(today.getMonth() + 1)];
    for (let i = 1; i < 7; i++) {
      let newDate = new Date(today.setDate(today.getDate() - 1));
      let newDay = newDate.getDate();
      if (newDay < 10) {
        newDay = "0" + newDay.toString();
      }
      xAxis.push(newDay + "-" + String(newDate.getMonth() + 1));
    }
  } else if (unit == "month") {
    xAxis = [today.getMonth() + 1 + "-" + today.getFullYear()];
    for (let i = 1; i < 7; i++) {
      let newDate = new Date(today.setMonth(today.getMonth() - 1));
      let newMonth = newDate.getMonth() + 1;
      if (newMonth < 10) {
        newMonth = "0" + newMonth.toString();
      }
      xAxis.push(newMonth + "-" + newDate.getFullYear());
    }
  } else if (unit == "year") {
    for (let i = 0; i < 7; i++) {
      let newDate = new Date(today.setFullYear(today.getFullYear() - 1));
      xAxis.push(String(newDate.getFullYear() + 1));
    }
  }
  return xAxis;
}

console.log(getXAxis("hour"));
