const func = function () {
  console.log(this);
};

func();
